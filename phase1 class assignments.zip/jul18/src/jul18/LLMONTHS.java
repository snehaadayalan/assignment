package jul18;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Vector;

public class LLMONTHS {


public static void main(String args[]){
	LinkedList l1=new LinkedList();
	l1.add("May");
	l1.add("June");
	l1.add("July");
	l1.add("August");
	l1.add("April");
	l1.add("November");
	System.out.println("\nAfter adding 6 months: "+l1);
	l1.addLast("December");
	l1.addFirst("January");
	System.out.println("\nAfter Adding december and january: "+l1);
	l1.add(3,"March");
	l1.add(2,"Febraury");
	l1.add(9,"September");
	l1.add(10,"October");
	System.out.println("\nAfter adding using index: "+l1);
	l1.set(1, "Febraury");
	l1.remove(2);
	l1.add(4,"May");
	l1.add(5,"June");
	l1.remove(2);
	l1.remove(8);
	l1.add(3,"April");
	l1.add(11,"November");
	l1.remove(8);
	System.out.println("\nPrinting Months in OrderWise: "+l1);
	System.out.println("\nOdd Months");
	for(int i=0;i<l1.size();i++)
	{
		if(i%2==0)
		{
			System.out.println(l1.get(i));
		}
		
	}
	System.out.println("\nEven Months");
	for(int i=0;i<l1.size();i++)
	{
		if(i%2!=0)
		{
			System.out.println(l1.get(i));
		}
		
	}
	
	System.out.println("\nPrinting Contents using iterator");
	Iterator it=l1.iterator();
	while(it.hasNext())
	{
		System.out.println(it.next());
		
	}
	
	System.out.println("\nFirst Month: "+l1.getFirst());
	System.out.println("\nLast Month: "+l1.getLast());
	
	l1.remove("July");
	System.out.println("\nAfter Removing Birthday Month: "+l1);
	
	if(l1.contains("December")&&l1.contains("January")&&l1.contains("Febraury"))
	{
		System.out.println("\nYes the Winter Months December, January  & Febraury are present");
	}
	
	System.out.println("\nFinal Linked List Elements: "+l1);
	
	
	
	



}

}