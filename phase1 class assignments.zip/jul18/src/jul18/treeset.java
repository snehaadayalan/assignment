package jul18;

import java.util.LinkedHashSet;
import java.util.TreeSet;

public class treeset {

public static void main(String[] args) {
		
		TreeSet lhs = new TreeSet();  // object creation of LinkedHashSet generic
		lhs.add("java");
		lhs.add("python");
		lhs.add("c");
		lhs.add("c++");

		
		System.out.println("the treeset is:" + lhs);
		
		System.out.println("the treeset is:" + lhs.size());
		System.out.println("the treeset is:" + lhs.remove("c++"));
		System.out.println("the treeset is:" + lhs.remove("c"));

		System.out.println("the treeset is:" + lhs.add("sql"));

		System.out.println("the treeset is:" + lhs.contains("java"));
	

	}

}

