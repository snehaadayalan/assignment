package phase2_program;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String name = req.getParameter("username");
        String age1 = req.getParameter("age");
        int age = Integer.parseInt(age1);
		PrintWriter out = resp.getWriter();
		out.println("\nYour name is "+name+" and your age is "+age1);
		
		System.out.println("Login ok");
		

	}
}